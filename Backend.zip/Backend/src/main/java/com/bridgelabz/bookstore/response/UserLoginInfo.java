/**
 * 
 */
package com.bridgelabz.bookstore.response;


public class UserLoginInfo {

}
