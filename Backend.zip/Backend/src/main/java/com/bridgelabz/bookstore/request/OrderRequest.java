package com.bridgelabz.bookstore.request;

public class OrderRequest {

}
