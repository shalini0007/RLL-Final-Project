import { DashboardComponent } from './Component/dashboard/dashboard.component';
import { SellerComponent } from './Component/seller/seller/seller.component';
import { RegistrationComponent } from './Component/auth/registration/registration.component';
import { LoginComponentComponent } from './Component/auth/login-component/login-component.component';
import { ForgetPasswordComponent } from './Component/auth/forget-password/forget-password.component';
import { ResetPasswordComponent } from './Component/auth/reset-password/reset-password.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GiverateComponent } from './Component/giverate/giverate.component';
import { AdminunverifiedbooksComponent } from './Component/adminunverifiedbooks/adminunverifiedbooks.component';
import { RatereviewComponent } from './Component/ratereview/ratereview.component';
import { RatedbooksComponent } from './Component/ratedbooks/ratedbooks.component';
import { BookreviewsComponent } from './Component/bookreviews/bookreviews.component';
import { PagenotfoundComponent } from './component/pagenotfound/pagenotfound.component';
import { HomepageComponent } from './component/homepage/homepage.component';
import { AboutusComponent } from './component/aboutus/aboutus.component';
import { ContactusComponent } from './component/contactus/contactus.component';
import { HeaderComponent } from './component/header/header.component';
const routes: Routes = [

  {
    path: '', redirectTo: 'home',
    pathMatch: 'full'
  },
  {path: 'books', component: DashboardComponent},
  {path: 'update-password/:token', component: ResetPasswordComponent},
  {path: 'forget-password', component: ForgetPasswordComponent},
  {path: 'login', component: LoginComponentComponent},
  {path: 'seller', component: SellerComponent},
  {path: 'register', component: RegistrationComponent},
  {path: 'books/rateandreview/:bookId', component: GiverateComponent},
  {path: 'verifybook', component: AdminunverifiedbooksComponent},
  {path: 'books/info/:bookId', component: RatereviewComponent},
  {path: 'books/:book', component: SellerComponent},
  {path: 'register', component: RegistrationComponent},
  {path: 'books/rateandreview/:bookId/:token', component: GiverateComponent},
  {path: 'verifybook', component: AdminunverifiedbooksComponent},
  {path: 'books/reviews/:bookId', component: RatereviewComponent},
  {path: 'ratedbooks', component: RatedbooksComponent},
  {path: 'bookreviews', component: BookreviewsComponent},
  {path: 'home', component: HomepageComponent},
  {path: 'about', component: AboutusComponent},
  {path: 'contact', component: ContactusComponent},
  {path: 'header', component: HeaderComponent},
  {path: '**', component: PagenotfoundComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
