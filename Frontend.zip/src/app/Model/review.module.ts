export class ReviewModel{
  rating : number = 0;
  review : string = '';
  id: number;
}