import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ReviewModel } from 'src/app/Model/review.module';
import { ReviewService } from '../../Service/review.service'

@Component({
  selector: 'app-giverate',
  templateUrl: './giverate.component.html',
  styleUrls: ['./giverate.component.scss']
})
export class GiverateComponent implements OnInit {

  formValue !: FormGroup;
  reviewModelObj : ReviewModel = new ReviewModel();
  reviewData !: any;
  showAdd !: boolean;
  showUpdate !: boolean;
  constructor(private formbuilder: FormBuilder,
  private api : ReviewService) {}

  ngOnInit(): void {
    this.formValue = this.formbuilder.group({
      review : [''],
      rating : ['']
    })
    this.getAllReview();
  }

  clickAddReview(){
    this.formValue.reset()
    this.showAdd = true;
    this.showUpdate = false;
  }

  postReviewDetails(){
    this.reviewModelObj.rating = this.formValue.value.rating;
    this.reviewModelObj.review = this.formValue.value.review;

    this.api.postReview(this.reviewModelObj)
    .subscribe(res=>{
      console.log(res);
      alert("Review added successfully")
      let ref = document.getElementById('close')
      ref?.click();
      this.formValue.reset();
      this.getAllReview();
    },
    err=>{
      alert("Something went wrong")
    })
  }

  getAllReview(){
    this.api.getReview()
    .subscribe(res=>{
      this.reviewData = res;
    })
  }

  deleteReview(row : any){
    console.log(row);
    this.api.deleteReview(row.id)
    .subscribe(res=>{
      alert("Review Deleted");
      this.getAllReview();
    })
  }

  onEdit(row : any){
    this.showAdd = false;
    this.showUpdate = true;
    this.reviewModelObj.id = row.id;
    this.formValue.controls['review'].setValue(row.review);
    this.formValue.controls['rating'].setValue(row.rating);
  }

  updateReviewDetails(){
    this.reviewModelObj.rating = this.formValue.value.rating;
    this.reviewModelObj.review = this.formValue.value.review;
    this.api.updateReview(this.reviewModelObj, this.reviewModelObj.id)
    .subscribe(res=>{
      alert("Updated Successfully");
      let ref = document.getElementById('close')
      ref?.click();
      this.formValue.reset();
      this.getAllReview();
    })
  }
}