import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ordergreeting',
  templateUrl: './ordergreeting.component.html',
  styleUrls: ['./ordergreeting.component.scss']
})
export class OrdergreetingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
